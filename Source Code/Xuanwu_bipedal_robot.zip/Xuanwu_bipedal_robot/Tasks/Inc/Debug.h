#ifndef DEBUG_H
#define DEBUG_H

#ifdef __cplusplus
extern "C" {
#endif

extern void Debug_Task(void const * argument);

#ifdef __cplusplus
}
#endif


#endif
	